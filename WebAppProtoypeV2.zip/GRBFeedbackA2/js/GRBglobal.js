/**
 * File Name: GRBglobal
 *
 * Revision History:
 *       Gloria Rivas-Bonilla, 2/16/2023 : Created
 */
function btnCalculateAverageAdd_click() {
    showCurrentRatingAdd();
}

function btnCalculateAverageModify_click() {
    showCurrentRatingModify();
}

function btnSave_click() {
    addFeedback();
}

function btnUpdate_click() {
    modifyFeedback();
}

function btnSaveDefault_click() {
    saveDefault();
}

//ready function
function init(){
    //check box is checked, will toggle between showing and hidden
    $("#chkAddRatings").click(function(){
        $("#hide").toggle();
    });
    $("#chkAddRatingsModify").click(function(){
        $("#hideModify").toggle();
    });
    //automatically fills in average rating on add page when text boxes are used
    $("#txtValue").on("change",btnCalculateAverageAdd_click);
    $("#txtService").on("change",btnCalculateAverageAdd_click);
    $("#txtFoodQuality").on("change",btnCalculateAverageAdd_click);
    //autofill average for the modify page
    $("#txtValueModify").on("change",btnCalculateAverageModify_click);
    $("#txtServiceModify").on("change",btnCalculateAverageModify_click);
    $("#txtFoodQualityModify").on("change",btnCalculateAverageModify_click);
    //add button for add page
    $("#btnSave").on("click", btnSave_click);
    //add button for modify page
    $("#btnUpdate").on("click", btnUpdate_click);
    //saveDefault button on settings page
    $("#btnSaveDefault").on("click", btnSaveDefault_click);
}

//ready event
$(document).ready(function () {
    init();
    //initially hides the ratings until checked
    $("#hide").hide();
    $("#hideModify").hide();
});