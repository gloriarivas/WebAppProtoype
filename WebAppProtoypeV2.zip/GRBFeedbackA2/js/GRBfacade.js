/**
 * File Name: GRBfacade
 *
 * Revision History:
 *       Gloria Rivas-Bonilla, 2/16/2023 : Created
 */

//show the average rating for add page
const showCurrentRatingAdd = () =>{
    let quality = $("#txtFoodQuality").val();
    let service = $("#txtService").val();
    let value = $("#txtValue").val();
    let averageRating = getRatingAverageAdd(quality, service, value);
    console.log(averageRating);
    $("#txtOverallRating").val(averageRating + '%');
}
//show the average rating for the modify page
const showCurrentRatingModify = () =>{
    let quality = $("#txtFoodQualityModify").val();
    let service = $("#txtServiceModify").val();
    let value = $("#txtValueModify").val();
    let averageRating = getRatingAverageModify(quality,service,value);
    console.log(averageRating);
    $("#txtOverallRatingModify").val(averageRating + "%");
}
//save feedback button
function addFeedback(){
    if (doValidation_frmAdd()){
        console.log("Add Form is valid");
    }
    else{
        console.log("Add Form is invalid");
    }
}
//modify feedback button (update button)
function modifyFeedback(){
    if (doValidation_frmModify()){
        console.log("Modify Form is valid");
    }
    else{
        console.log("Modify Form is invalid");
    }
}

//save default email to local storage
function saveDefault(){
    //adding item to the local storage
    localStorage.setItem("email", $("#txtDefaultEmail").val());
    alert("Default reviewer email saved");
}